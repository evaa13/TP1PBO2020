﻿using Pembelian.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pembelian
{
    public partial class FrmBeli : Form
    {
        public ListItem[] listitems = new ListItem[6];
        public FrmBeli()
        {
            InitializeComponent();
        }

        private void FrmBeli_Load(object sender, EventArgs e)
        {
            PopulateItem();
            
        }

        private void PopulateItem()
        {
            
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbHarga_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
           
            
        }

        private void cbJenis_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
